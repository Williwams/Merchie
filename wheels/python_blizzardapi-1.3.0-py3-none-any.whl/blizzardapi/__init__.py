"""__init__.py file."""
from requests.exceptions import *  # noqa

from .blizzard_api import BlizzardApi  # noqa
